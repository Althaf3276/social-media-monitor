import asyncio
import aiohttp
import os
import logging
from datetime import datetime
from typing import Dict, List, Optional
from dataclasses import dataclass

@dataclass
class AccountMonitor:
    platform: str
    identifier: str
    last_seen: Optional[Dict] = None
    interval: int = 60  # seconds

class SocialMediaMonitor:
    def __init__(self, config_path: str = "monitors.json"):
        self.config_path = config_path
        self.monitors: List[AccountMonitor] = []
        self.setup_logging()
        
    def setup_logging(self):
        """Configure logging for the monitor"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler("monitor.log"),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger("SocialMediaMonitor")
    
    def load_config(self) -> List[Dict]:
        """Load monitor configuration from JSON file"""
        try:
            with open(self.config_path) as f:
                return json.load(f)
        except FileNotFoundError:
            self.logger.error(f"Config file {self.config_path} not found")
            return []
    
    async def _check_instagram(self, monitor: AccountMonitor) -> Optional[Dict]:
        """Check Instagram for profile/activity changes"""
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0',
                'Accept': 'application/json'
            }
            url = f"https://www.instagram.com/{monitor.identifier}/?__a=1"
            async with aiohttp.ClientSession(headers=headers) as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            'bio': data['graphql']['user']['biography'],
                            'posts': data['graphql']['user']['edge_owner_to_timeline_media']['count'],
                            'followers': data['graphql']['user']['edge_followed_by']['count'],
                            'last_updated': datetime.now().isoformat()
                        }
        except Exception as e:
            self.logger.error(f"Instagram check failed: {str(e)}")
        return None
    
    async def _check_twitter(self, monitor: AccountMonitor) -> Optional[Dict]:
        """Check Twitter for profile/activity changes"""
        try:
            bearer_token = os.environ.get("TWITTER_BEARER_TOKEN")
            if not bearer_token:
                raise ValueError("Missing Twitter Bearer Token")
                
            headers = {
                'Authorization': f'Bearer {bearer_token}',
                'Content-Type': 'application/json'
            }
            url = f"https://api.twitter.com/2/users/by/username/{monitor.identifier}"
            params = {'user.fields': 'description,profile_image_url,created_at'}
            
            async with aiohttp.ClientSession(headers=headers) as session:
                async with session.get(url, params=params) as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            'description': data['data'].get('description', ''),
                            'profile_image_url': data['data'].get('profile_image_url', ''),
                            'created_at': data['data'].get('created_at', ''),
                            'last_updated': datetime.now().isoformat()
                        }
        except Exception as e:
            self.logger.error(f"Twitter check failed: {str(e)}")
        return None
    
    async def _check_facebook(self, monitor: AccountMonitor) -> Optional[Dict]:
        """Check Facebook for profile/activity changes"""
        try:
            access_token = os.environ.get("FACEBOOK_ACCESS_TOKEN")
            if not access_token:
                raise ValueError("Missing Facebook Access Token")
                
            headers = {'Authorization': f'Bearer {access_token}'}
            url = f"https://graph.facebook.com/v18.0/{monitor.identifier}"
            params = {'fields': 'name,picture,bio,link,updated_time'}
            
            async with aiohttp.ClientSession(headers=headers) as session:
                async with session.get(url, params=params) as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            'name': data.get('name', ''),
                            'bio': data.get('bio', ''),
                            'updated_time': data.get('updated_time', ''),
                            'last_updated': datetime.now().isoformat()
                        }
        except Exception as e:
            self.logger.error(f"Facebook check failed: {str(e)}")
        return None
    
    async def _check_whatsapp(self, monitor: AccountMonitor) -> Optional[Dict]:
        """Check WhatsApp for status updates"""
        try:
            # Using WhatsApp Business API
            access_token = os.environ.get("WHATSAPP_ACCESS_TOKEN")
            if not access_token:
                raise ValueError("Missing WhatsApp Access Token")
                
            headers = {
                'Authorization': f'Bearer {access_token}',
                'Content-Type': 'application/json'
            }
            url = f"https://graph.facebook.com/v18.0/{monitor.identifier}/status"
            
            async with aiohttp.ClientSession(headers=headers) as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            'status': data.get('status', ''),
                            'last_updated': datetime.now().isoformat()
                        }
        except Exception as e:
            self.logger.error(f"WhatsApp check failed: {str(e)}")
        return None
    
    async def check_platform(self, monitor: AccountMonitor) -> bool:
        """Check a single platform for changes"""
        if monitor.platform == "instagram":
            result = await self._check_instagram(monitor)
        elif monitor.platform == "twitter":
            result = await self._check_twitter(monitor)
        elif monitor.platform == "facebook":
            result = await self._check_facebook(monitor)
        elif monitor.platform == "whatsapp":
            result = await self._check_whatsapp(monitor)
        else:
            self.logger.warning(f"Unsupported platform: {monitor.platform}")
            return False
            
        if result and monitor.last_seen:
            # Compare with previous state
            changes = []
            for key, value in result.items():
                if key != 'last_updated' and key in monitor.last_seen:
                    if value != monitor.last_seen[key]:
                        changes.append(f"{key}: {monitor.last_seen[key]} -> {value}")
            
            if changes:
                self.logger.info(f"Changes detected for {monitor.platform}/{monitor.identifier}: {', '.join(changes)}")
                monitor.last_seen = result
                return True
                
        monitor.last_seen = result
        return False
    
    async def run_monitor(self, monitor: AccountMonitor):
        """Run continuous monitoring for a specific account"""
        self.logger.info(f"Starting monitor for {monitor.platform}/{monitor.identifier}")
        
        while True:
            try:
                await self.check_platform(monitor)
                await asyncio.sleep(monitor.interval)
            except KeyboardInterrupt:
                break
            except Exception as e:
                self.logger.error(f"Monitor error: {str(e)}")
                await asyncio.sleep(60)  # Retry after error
    
    async def start_all_monitors(self):
        """Load config and start all monitors"""
        config = self.load_config()
        if not config:
            return
            
        for item in config:
            monitor = AccountMonitor(
                platform=item['platform'],
                identifier=item['identifier'],
                interval=item.get('interval', 60)
            )
            self.monitors.append(monitor)
            
        # Start all monitors concurrently
        tasks = [self.run_monitor(monitor) for monitor in self.monitors]
        await asyncio.gather(*tasks)

# Usage example
async def main():
    monitor = SocialMediaMonitor()
    await monitor.start_all_monitors()

if __name__ == "__main__":
    asyncio.run(main())